Segment Developer Tools
=======================

Prerequisites
-------------

* Windows 7 SP1 or greater
* [Node.js](https://nodejs.org/en/) v4.5.0 or greater
* npm v2.15.9 or greater

From a command prompt, use the following commands to confirm that you have appropriate versions of Node.js and npm.

> node --version
> npm --version

How to build the Segment Developer Tools
----------------------------------------

If you are inside a private network, configure your npm proxy.

> npm config set proxy <proxy URL>
> npm config set https-proxy <proxy URL>

Unzip the Segment Developer Tools package, and change directories to the root folder for the unzipped files.

> cd SegmentDeveloperTools

Install the node modules for the Segment Developer Tools app.

> npm install

Build the application.  
The application is created as `SegmentDeveloperTools.exe` in the `dist\SegmentDeveloperTools-win32-ia32` subdirectory.

> npm run build
