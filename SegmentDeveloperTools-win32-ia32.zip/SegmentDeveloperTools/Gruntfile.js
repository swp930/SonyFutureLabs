module.exports = function (grunt) {

    'use strict';

    const packageInfo = require('./package.json');
    const packager = require('electron-packager');

    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-contrib-copy');

    grunt.initConfig({
        clean: {
            'dist': 'dist/**/*',
            'dist-app': `dist/${packageInfo.name}-win32-ia32/resources/app/**/*`,
            'license': [
                `dist/${packageInfo.name}-win32-ia32/LICENSE`,
                `dist/${packageInfo.name}-win32-ia32/version`
            ]
        },
        copy: {
            'dist-app': {
                expand: true,
                cwd: `dist/${packageInfo.name}-win32-ia32/resources/app/`,
                src: [
                    'app.asar.unpacked/**/*',
                    'app.asar'
                ],
                dest: `dist/${packageInfo.name}-win32-ia32/resources/`
            }
        }
    });

    grunt.registerTask('package', function () {
        var done = this.async();

        var options = {
            'dir': './app',
            'name': packageInfo.name,
            'app-version': packageInfo.version,
            'icon': 'sfl_sdk.ico',
            'out': 'dist',
            'overwrite': true,
            'version': packageInfo.dependencies['electron-prebuilt'],
            'platform': 'win32',
            'arch': 'ia32',
            'prune': false,
            'version-string': {
                'CompanyName': 'SONY',
                'LegalCopyright': 'Copyright 2016 Sony Corporation',
                'FileDescription': packageInfo.description,
                'OriginalFilename': packageInfo.name,
                'FileVersion': packageInfo.version,
                'ProductVersion': packageInfo.version,
                'ProductName': packageInfo.productName,
                'InternalName': packageInfo.name
            }
        };

        packager(options, error => {
            if (error) {
                grunt.fail.fatal(error);
            } else {
                done();
            }
        });
    });

    grunt.registerTask('build', [
        'clean:dist',
        'package',
        'copy:dist-app',
        'clean:dist-app',
        'clean:license'
    ]);
};
